//#-hidden-code

import SwiftUI
import SpriteKit
import PlaygroundSupport

var ant1, ant2, ant3, ant4, ant5: [(Direction, TileColor)]
//#-end-hidden-code

/*:
 
 # Multiple Ants
 This simulator gives you the option to add multiple ants. You can create up to 5 ants and add them wherever you like. Each ant's pattern is customizable with the upcoming code.
 
 * Callout(New simulator functions):
 Select the ant you want to add with the lower-left buttons.
 Add an ant to the scene by taping the point where you want to add it.
 Pause the scene to add multiple ants at the same time.
 
 Keep in mind that each ant pattern is an array of tuples, the first value is the direction, and the second one the color (This is for you to have more control and be able to have more options. The ant will follow the array order to change from one square color to another one.
 
 - Important:
 If you add the same color to an ant more than twice it will never go further than the second color.
 
 **Run the playground and start playng with the different ants.**

 */
// Color selection
ant1 = [(.left, .blue), (.right, .teal)]

ant2 = [/*#-editable-code (Direction, Color)*/(.left, .green), (.right, .red), (.left, .yellow)/*#-end-editable-code*/]
    
ant3 = [/*#-editable-code (Direction, Color)*/(.left, .orange), (.left, .teal), (.right, .blue), (.right, .red)/*#-end-editable-code*/]

ant4 = [/*#-editable-code (Direction, Color)*/(.left, .indigo), (.right, .orange), (.right, .blue), (.left, .red), (.left, .yellow)/*#-end-editable-code*/]

ant5 = [/*#-editable-code (Direction, Color)*/(.left, .indigo), (.right, .orange), (.right, .blue), (.right, .red), (.right, .yellow), (.right, .green), (.left, .teal), (.left, .purple), (.right, .white)/*#-end-editable-code*/]

/*:
 It's really cool to see how each ant creates its own patterns and starts interacting with the patterns other ants have created. Sometimes one ant follows another one, other ones fall into an endless loop. Some appear to be fighting for the scene, and others seem to help each other.
 
 It's really amazing how with such simple instructions you can create these behaviors, and they are not just nice-looking patterns but also a start point to map creation and even artificial intelligence. I've really loved this playground, and hopefully you too.

 Thank You 🙂
*/
   

//#-hidden-code
savedAnts.append(contentsOf: [Ant(size: CGSize(width: 10, height: 10), pattern: ant1), Ant(size: CGSize(width: 10, height: 10), pattern: ant2), Ant(size: CGSize(width: 10, height: 10), pattern: ant3), Ant(size: CGSize(width: 10, height: 10), pattern: ant4), Ant(size: CGSize(width: 10, height: 10), pattern: ant5)])

struct SimulatorView: View {
    
    var scene: SKScene {
        let scene = GameScene(speed: 1)
        scene.size = CGSize(width: 1000, height: 1000)
        scene.scaleMode = .aspectFit
        scene.anchorPoint = CGPoint(x: 0, y: 0)
        
        return scene
    }
    
    var body: some View {
        SpriteView(scene: scene, preferredFramesPerSecond: 30)
            
    }
}

PlaygroundPage.current.setLiveView(SimulatorView())
//#-end-hidden-code
