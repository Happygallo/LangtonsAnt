//#-hidden-code

import SwiftUI
import SpriteKit
import PlaygroundSupport

//#-end-hidden-code

/*:
 
 # Langton's Ant
 Hi, my name is Javier and I'm a visual arts student.
  
 Today I want to teach you about Langton's Ant in this swift playground I made using SpriteKit.
 
 
 ## Simple instructions can create complex patterns
 
 Langton's Ant is a simple system in which, within a grid of squares, there is an imaginary ant. This ant moves from one square to another following two simple rules:
  
 1. If the ant is on a white square, change the square color to black, turn 90° to the left, and move forward one square.
  
 2. If the ant is on a black square, change the square color to white, turn 90° to the right, and move forward one square.
 
 - Note: In this simulation, I created a toroidal grid, which means when the ant gets to the edge of the scene it continues from the opposite edge. In other words, there are no limits and the ant will keep moving, just as in Earth!
 
 ![Langton's Ant grid example](LangtonsAntAnimated.gif)
 Source [Wikipedia](https://en.wikipedia.org/wiki/Langton%27s_ant)
 
 **Run the playground to see the ant in action and the pattern it creates.**
 
 * Callout(How to use the simulation?):
 Speed up or down the simulation with the upper-left buttons.
 Pause and restart the simulation with the upper-right buttons.
 Forward one step with the lower-right button.
  
 As you saw, the ant started with a very simple pattern, then it turned into complete chaos, and finally it created what is called a railway (where the pattern repeated itself). But that's not the case with all the patterns you can make, it's time to create more patterns by adding simple instructions.
 
 [Next Page: Complex Patterns](@next)
 */

//#-hidden-code

savedAnts.append(Ant(size: CGSize(width: 10, height: 10), pattern: [(.left, .white), (.right, .black)]))

struct LangtonAntView: View {
    
    var scene: SKScene {
        let scene = LangtonAnt(speed: 1)
        scene.size = CGSize(width: 1000, height: 1000)
        scene.scaleMode = .aspectFit
        scene.anchorPoint = CGPoint(x: 0, y: 0)
        
        return scene
    }
    
    var body: some View {
        SpriteView(scene: scene, preferredFramesPerSecond: 30)
    }
}

PlaygroundPage.current.setLiveView(LangtonAntView())
//#-end-hidden-code
