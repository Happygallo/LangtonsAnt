//#-hidden-code

import SwiftUI
import SpriteKit
import PlaygroundSupport

var pattern: Patterns

enum Patterns {
    case LR
    case LRL
    case LLRR
    case LRRRRRLLR
    case RRLLLRLLLRRR
}

//#-end-hidden-code

/*:
 
 # Complex Patterns
 Now that you understand Langton's Ant we can start giving it more complexity by adding more instructions.
 
 To do this I added 9 new colors, and we will refer to each instruction as a character: `L` for left and `R` for Right. The previous page example was an `LR` pattern but now there are some new ones to check.
 
 **Try using the different premade patterns by changing the following code and running the playground.**
 
 - Example:\
 My favorite patter is `.LRRRRRLLR`
 */
// Pattern selection
pattern = /*#-editable-code Patterns*/.LRL/*#-end-editable-code*/
/*:
 As you can see each set of instructions creates its own complex patterns, each one with its uniqueness and esthetic. Since now you know different possible patterns it's time for you to create your own. And not with just one ant but with multiple!
 
 [Next Page: Multiple Ants](@next)
*/

//#-hidden-code

var antPattern: [(Direction, TileColor)]

switch pattern {
case .LRL:
    antPattern = [(.left, .white), (.right, .black), (.left, .blue)]
case .LR:
    antPattern = [(.left, .white), (.right, .black)]
case .LLRR:
    antPattern = [(.left, .white), (.left, .black), (.right, .blue), (.right, .red)]
case .LRRRRRLLR:
    antPattern = [(.left, .white), (.right, .black), (.right, .blue), (.right, .red), (.right, .yellow), (.right, .green), (.left, .teal), (.left, .purple), (.right, .indigo)]
case .RRLLLRLLLRRR:
    antPattern = [(.right, .white), (.right, .black), (.left, .blue), (.left, .red), (.left, .yellow), (.right, .green), (.left, .teal), (.left, .purple), (.left, .indigo), (.right, .pink), (.right, .orange), (.right, .gray)]
}

savedAnts.append(Ant(size: CGSize(width: 10, height: 10), pattern: antPattern))

struct AntPatterns: View {
    
    var scene: SKScene {
        let scene = LangtonAnt(speed: 1)
        scene.size = CGSize(width: 1000, height: 1000)
        scene.scaleMode = .aspectFit
        scene.anchorPoint = CGPoint(x: 0, y: 0)
        
        return scene
    }
    
    var body: some View {
        SpriteView(scene: scene, preferredFramesPerSecond: 30)
            
    }
}

PlaygroundPage.current.setLiveView(AntPatterns())
//#-end-hidden-code
