//
//  SKButton.swift
//  TestAntSwiftUI
//
//  Created by Javier Gallo Roca on 14/04/21.
//

import SpriteKit

class SKButton: SKNode {
    var button: SKSpriteNode
    var primaryImage: String
    var secondaryImage: String
    var usingPrimaryImage = true
    private var action: () -> Void
    var isEnabled = true
    
    public init(primaryImage: String, secondaryImage: String, buttonAction: @escaping () -> Void) {
        self.primaryImage = primaryImage
        self.secondaryImage = secondaryImage
        
        button = SKSpriteNode(imageNamed: primaryImage)
        
        action = buttonAction
        
        super.init()
        
        isUserInteractionEnabled = true
        
        setupNodes()
        addNodes()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupNodes() {
        button.zPosition = 11
    }
    
    func addNodes() {
        addChild(button)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isEnabled {
            button.alpha = 0.5
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isEnabled {
            action()
            button.alpha = 1.0
        }
    }
    
    func disable() {
        isEnabled = false
        button.alpha = 0.5
    }
    
    func enable() {
        isEnabled = true
        button.alpha = 1.0
    }
    
    func changeTexture() {
        if usingPrimaryImage {
            button.texture = SKTexture(imageNamed: secondaryImage)
            usingPrimaryImage = false
        } else {
            button.texture = SKTexture(imageNamed: primaryImage)
            usingPrimaryImage = true
        }
    }
    
}
