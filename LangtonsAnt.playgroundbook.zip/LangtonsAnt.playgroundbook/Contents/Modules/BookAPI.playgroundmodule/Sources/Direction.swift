
//
//  Direction.swift
//  TestAnt
//
//  Created by Javier Gallo Roca on 6/04/21.
//

import Foundation

public enum Direction {
    case up
    case right
    case down
    case left
}
