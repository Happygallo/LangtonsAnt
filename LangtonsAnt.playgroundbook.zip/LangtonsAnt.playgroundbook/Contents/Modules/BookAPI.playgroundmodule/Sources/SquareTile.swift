
//
//  SquareTile.swift
//  TestAnt
//
//  Created by Javier Gallo Roca on 6/04/21.
//

import Foundation
import SpriteKit

public class SquareTile {
    var tile: SKTileGroup!
    var color: TileColor!
    var key: String!
    
    init(color: TileColor) {
        let tileSet = tilesMap.tileSet
        
        var name: String!
        
        switch color {
        case .blue:
            name = "Blue"
            self.key = "blueTile"
        case .green:
            name = "Green"
            self.key = "greenTile"
        case .indigo:
            name = "Indigo"
            self.key = "indigoTile"
        case .orange:
            name = "Orange"
            self.key = "orangeTile"
        case .pink:
            name = "Pink"
            self.key = "pinkTile"
        case .purple:
            name = "Purple"
            self.key = "purpleTile"
        case .red:
            name = "Red"
            self.key = "redTile"
        case .teal:
            name = "Teal"
            self.key = "tealTile"
        case .yellow:
            name = "Yellow"
            self.key = "yellowTile"
        case .white:
            name = "White"
            self.key = "whiteTile"
        case .gray:
            name = "Gray"
            self.key = "grayTile"
        case .black:
            name = "Black"
            self.key = "blackTile"
        }
        
        let tile = tileSet.tileGroups.first(where: {$0.name == name})
        self.tile = tile
        self.color = color
    }
}
