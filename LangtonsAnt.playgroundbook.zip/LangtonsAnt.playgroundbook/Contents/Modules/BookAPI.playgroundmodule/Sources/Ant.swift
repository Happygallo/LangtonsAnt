
//
//  Ant.swift
//  TestAnt
//
//  Created by Javier Gallo Roca on 5/04/21.
//

import SpriteKit
import GameplayKit
import Foundation

public enum TileColor {
    case blue
    case green
    case indigo
    case orange
    case pink
    case purple
    case red
    case teal
    case yellow
    case white
    case gray
    case black
}

public class Ant: SKSpriteNode {
    
    var direction: Direction = .up
    var pattern: [(instruction: Direction, color: TileColor)] = []
    var tileSize: CGFloat!
    var colorUI: UIColor!
    
    public init(size: CGSize, pattern: [(Direction, TileColor)]) {
        super.init(texture: nil, color: .clear, size: size)
        self.pattern = pattern
        self.tileSize = size.height
        setColor()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func turnLeft() {
        switch direction {
        case .up:
            direction = .left
        case .left:
            direction = .down
        case .down:
            direction = .right
        case .right:
            direction = .up
        }
    }
    
    func turnRight() {
        switch direction {
        case .up:
            direction = .right
        case .right:
            direction = .down
        case .down:
            direction = .left
        case .left:
            direction = .up
        }
    }
    
    func turnBack() {
        switch direction {
        case .up:
            direction = .down
        case .right:
            direction = .left
        case .down:
            direction = .up
        case .left:
            direction = .right
        }
    }
    
    func moveTile() {
        switch direction {
        case .down:
            self.position.y -= 10
        case .right:
            self.position.x += 10
        case .up:
            self.position.y += 10
        case .left:
            self.position.x -= 10
        }
    }
    
    func setColor() {
        switch pattern.first?.color {
        case .blue:
            colorUI = .systemBlue
        case .green:
            colorUI = .systemGreen
        case .indigo:
            colorUI = .systemIndigo
        case .orange:
            colorUI = .systemOrange
        case .pink:
            colorUI = .systemPink
        case .purple:
            colorUI = .systemPurple
        case .red:
            colorUI = .systemRed
        case .teal:
            colorUI = .systemTeal
        case .yellow:
            colorUI = .systemYellow
        case .white:
            colorUI = .white
        case .gray:
            colorUI = .systemGray
        case .black:
            colorUI = .black
        case .none:
            colorUI = .clear
        }
    }
}
