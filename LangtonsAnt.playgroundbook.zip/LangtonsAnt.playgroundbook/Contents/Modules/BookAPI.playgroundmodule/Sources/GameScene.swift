//
//  GameScene.swift
//  TestAnt
//
//  Created by Javier Gallo Roca on 2/04/21.
//

import SpriteKit
import GameplayKit
import SwiftUI

public var tilesMap: SKTileMapNode!
public var pattern: [(Character, TileColor)] = [("L", .red), ("R", .yellow)]
public var savedAnts: [Ant] = []


public class GameScene: SKScene {
    var simulationSpeed: Int
    var simulationPaused = false
    var ants: [Ant] = []
    var buttonPause: SKShapeNode?
    var tileSize: CGFloat!
    var selectedAnt: Ant = savedAnts.first!
    
    var resetButton: SKButton!
    var playButton: SKButton!
    var nextButton: SKButton!
    var antButtons: [SKButton] = []
    var speedButtons: [SKButton] = []
    
    var selectedSpeedButton = 0
    var selectedAntButton = 0
    
    public init(speed: Int) {
        self.simulationSpeed = speed
        super.init(size: CGSize(width: 1000, height: 1000))
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func didMove(to view: SKView) {
        loadSceneNodes()
    }
    
    func loadSceneNodes() {
        
        let tileColors = ["Red", "Yellow", "Black", "Blue", "Teal", "Purple", "White", "Gray", "Pink", "Orange", "Green", "Indigo"]
        let tileKeys = ["redTile", "yellowTile", "blackTile", "blueTile", "tealTile", "purpleTile", "whiteTile", "grayTile", "pinkTile",  "orangeTile", "greenTile", "indigoTile"]
        
        var tileGroups: [SKTileGroup] = []
        
        for tile in 0..<tileKeys.count {
            let name = "\(tileColors[tile])"
            let texture = SKTexture(imageNamed: name)
            let definition = SKTileDefinition(texture: texture)
            let dictionary: NSMutableDictionary = ["\(tileKeys[tile])" : 0]
            definition.name = name
            definition.size = CGSize(width: 10, height: 10)
            definition.userData = dictionary
            let group = SKTileGroup(tileDefinition: definition)
            group.name = name
            
            tileGroups.append(group)
        }
        
        let tileSet = SKTileSet(tileGroups: tileGroups, tileSetType: .grid)
        
        let newTilesMap = SKTileMapNode(tileSet: tileSet, columns: 100, rows: 100, tileSize: CGSize(width: 10, height: 10))
        
        newTilesMap.anchorPoint = CGPoint(x: 0, y: 0)
        newTilesMap.name = "TilesMap"
        addChild(newTilesMap)
        
        tilesMap = childNode(withName: "TilesMap") as? SKTileMapNode
        
        setButtons()
    }
    
    
    // MARK: Setup Buttons
    
    func setButtons() {
        
        //Create Reset Button
        let newResetButton = SKButton(primaryImage: "ResetButton", secondaryImage: "ResetButton") {
            for ant in self.ants {
                ant.direction = .up
            }
            self.ants = []
            
            tilesMap.fill(with: nil)
        }
        newResetButton.position = CGPoint(x: 950, y: 950)
        resetButton = newResetButton
        addChild(resetButton)
        
        //Create Pause Button
        let button = SKButton(primaryImage: "PauseButton", secondaryImage: "PlayButton") {
            self.simulationPaused.toggle()
            self.playButton.changeTexture()
        }
        button.position = CGPoint(x: 860, y: 950)
        button.zPosition = 11
        playButton = button
        addChild(playButton)
        
        //Create Next Button
        let newNextButton = SKButton(primaryImage: "NextButton", secondaryImage: "NextButton") {
            self.simulationPaused = true
            for ant in self.ants {
                self.moveAnt(ant: ant)
            }
            
            if self.playButton.usingPrimaryImage {
                self.playButton.changeTexture()
            }
        }
        
        newNextButton.position = CGPoint(x: 950, y: 50)
        nextButton = newNextButton
        addChild(nextButton)
        
        //Create Ant Buttons
        let inactiveAntNames = ["Ant1Inactive", "Ant2Inactive", "Ant3Inactive", "Ant4Inactive", "Ant5Inactive"]
        let activeAntNames = ["Ant1Active", "Ant2Active", "Ant3Active", "Ant4Active", "Ant5Active"]
        
        var position = CGPoint(x: 75, y: 75)
        
        for ant in 0..<savedAnts.count {
            
            let antButton = SKButton(primaryImage: inactiveAntNames[ant], secondaryImage: activeAntNames[ant]) {
                self.selectedAnt = savedAnts[ant]
                for button in self.antButtons {
                    if button.usingPrimaryImage == false {
                        button.changeTexture()
                    }
                }
                self.antButtons[ant].changeTexture()
            }
            antButton.position = position
            antButtons.append(antButton)
            addChild(antButtons[ant])
            position.x += 125
        }
        
        antButtons[selectedAntButton].changeTexture()
        
        //Create Speed Buttons
        let speeds = [1, 10,100]
        let inactiveImageNames = ["1xInactive", "10xInactive", "100xInactive"]
        let activeImageNames = ["1xActive", "10xActive", "100xActive"]
        
        position = CGPoint(x: 50, y: 965)
        for speed in 0..<speeds.count {
            let speedButton = SKButton(primaryImage: inactiveImageNames[speed], secondaryImage: activeImageNames[speed]) {
                self.simulationSpeed = speeds[speed]
                for button in self.speedButtons {
                    if button.usingPrimaryImage == false {
                        button.changeTexture()
                    }
                }
                self.speedButtons[speed].changeTexture()
            }
            speedButton.position = position
            speedButtons.append(speedButton)
            addChild(speedButtons[speed])
            position.x += 85
        }
        
        speedButtons[selectedSpeedButton].changeTexture()
    }
    
    func touchDown(atPoint pos : CGPoint) {
        
        let newAnt = selectedAnt
        newAnt.position = pos
        self.ants.append(newAnt)
        
        if !newAnt.pattern.isEmpty {
            moveAnt(ant: newAnt)
        }
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
    }
    
    func touchUp(atPoint pos : CGPoint) {
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    public override func update(_ currentTime: TimeInterval) {
        if simulationPaused == false {
            for _ in 0...simulationSpeed {
                for ant in ants {
                    if !ant.pattern.isEmpty {
                        moveAnt(ant: ant)
                    }
                }
            }
        }
        
    }
    
    func moveAnt(ant: Ant) {
        
        let position = ant.position
        var column = tilesMap.tileColumnIndex(fromPosition: position)
        var row = tilesMap.tileRowIndex(fromPosition: position)
        
        if column >= tilesMap.numberOfColumns {
            column = 0
        } else if column <= -1 {
            column = tilesMap.numberOfColumns - 1
        }
        
        if row >= tilesMap.numberOfRows {
            row = 0
        } else if row <= -1 {
            row = tilesMap.numberOfRows - 1
        }
        
        ant.position = tilesMap.centerOfTile(atColumn: column, row: row)
        
        let tile = tilesMap.tileDefinition(atColumn: column, row: row)
        
        let pattern = ant.pattern
        var hasTile = false
        
        for step in 0..<pattern.count {
            let tileNode = SquareTile(color: pattern[step].color)
            if let _ = tile?.userData?.value(forKey: tileNode.key) {
                var newTile: SquareTile!
                
                if step >= pattern.count - 1 {
                    newTile = SquareTile(color: pattern[0].color)
                } else {
                    newTile = SquareTile(color: pattern[step + 1].color)
                }
                tilesMap.setTileGroup(newTile.tile, forColumn: column, row: row)
                
                switch pattern[step].instruction {
                case .left:
                    ant.turnLeft()
                case .right:
                    ant.turnRight()
                case .down:
                    ant.turnBack()
                case .up:
                    break
                }
                hasTile = true
                break
            }
            
        }
        
        if hasTile == false {
            let newTile = SquareTile(color: pattern[1].color)
            tilesMap.setTileGroup(newTile.tile, forColumn: column, row: row)
            
            ant.turnLeft()
        }
        
        ant.moveTile()
        
    }
}
